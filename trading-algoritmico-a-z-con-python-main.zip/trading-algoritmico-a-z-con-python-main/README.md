# Trading Algorítmico de la A a la Z con Python
🇪🇸 Puedes apuntarte en nuestro curso en: https://cursos.frogamesformacion.com/courses/trading-algoritmico-1

O obtener la Ruta completa de trading algorítmico en: https://cursos.frogamesformacion.com/bundles/ruta-trading 

### Recursos


💰 Únete a la comunidad de [Discord](https://discord.gg/z3dx5XpkX4)

📚 Puedes leer nuestro libro en [Amazon](https://www.amazon.es/Python-para-finanzas-trading-algor%C3%ADtmico-ebook/dp/B0BT4ZS9Q3)

🖥️ El canal de [YouTube de Quantreo's](https://www.youtube.com/channel/UCp7jckfiEglNf_Gj62VR0pw) (en inglés) y el de [Frogames](https://www.youtube.com/channel/UCMUxXNYrVCv6-bQakhomvBg) en Español



### VPS / Instalar Windows en tu Mac

VPS: https://billing.virmach.com/aff.php?aff=10561

BOOT CAMP MAC: https://www.youtube.com/watch?v=Hmm9Q-T0oTo

Parallels Desktop: https://www.parallels.com/


### Recursos

💰 Únete a la comunidad de Discord: https://discord.gg/wXjNPAc5BH

📚 Puedes leer nuestro libro en: https://www.amazon.com/gp/product/B09HG18CYL 

🖥️ El canal de YouTube de Quantreo's (en inglés): https://www.youtube.com/channel/UCp7jckfiEglNf_Gj62VR0pw



### VPS / Instalar Windows en tu Mac

VPS: https://billing.virmach.com/aff.php?aff=10561

BOOT CAMP MAC: https://www.youtube.com/watch?v=Hmm9Q-T0oTo

Parallels Desktop: https://www.parallels.com/
